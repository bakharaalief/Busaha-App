package com.busaha.busahaapp.domain.entity

data class UserRegister(
    val message: String
)
