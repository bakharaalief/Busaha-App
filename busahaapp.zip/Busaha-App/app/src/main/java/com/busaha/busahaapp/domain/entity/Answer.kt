package com.busaha.busahaapp.domain.entity

class Answer(
    val idQuestion: Int,
    val idAnswer: Int,
    val index: Int? = null
)