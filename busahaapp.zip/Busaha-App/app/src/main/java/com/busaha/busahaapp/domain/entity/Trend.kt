package com.busaha.busahaapp.domain.entity

data class Trend(
    val id: Int,
    val title: String,
    val desc: String
)
