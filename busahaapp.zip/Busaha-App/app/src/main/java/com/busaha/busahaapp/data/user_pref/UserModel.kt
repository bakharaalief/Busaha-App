package com.busaha.busahaapp.data.user_pref

data class UserModel(
    val localId: String,
    val displayName: String,
    val isLogin: Boolean
)