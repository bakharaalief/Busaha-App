package com.busaha.busahaapp.domain.entity

data class UserLogin(
    val localId: String,
    val displayName: String,
)
